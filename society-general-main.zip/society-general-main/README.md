# society-general
society general training files

# links
<ul>
  <li>caniuse.com</li>
  <li>developer.mozilla.org</li>
  <li>jsperf.app</li>
</ul>



<a href="https://docs.google.com/forms/d/e/1FAIpQLSfo6_-r5kpUhgnVfsHGCXzpbxmuwBMMJeF9PwabW9Jq2i4sOg/viewform">Intrim Feedback Link</a>

<a href="https://docs.google.com/forms/d/e/1FAIpQLSfo6_-r5kpUhgnVfsHGCXzpbxmuwBMMJeF9PwabW9Jq2i4sOg/viewform"> Last Day's Feedback </a>
